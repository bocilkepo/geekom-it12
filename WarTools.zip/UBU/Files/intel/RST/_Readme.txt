
# Only IRST files should be located in this folder.
# RaidOrom.bin DevID 2822/282a
# RaidDriver.efi