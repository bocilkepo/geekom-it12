# In this folder you can place the Intel GOP Driver you need.
# The file name format is - IntelGopDriver.efi