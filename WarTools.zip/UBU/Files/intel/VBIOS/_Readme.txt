#In this folder, the user places the files OROM Intel VBIOS
#WarAttention! This is aashno!
#Files OROM VBIOS should be pre-configured.
#UBU does not transfer settings, the user is supposed to do.
#
#The following files are allowed:
#
#for Sandy/Ivy Bridge
# - vbiossib.dat - support DevID 0102, 0162
#for Haswell/Broadwell
# - vbioshsw.dat - support DevID 0402, 0412, 0C02, 0C12, 0406,  0416
#for Skylake/Kabylake/Coffeelake
# - vbiosskl.dat - support DevIO 0406

vbtskl.bin