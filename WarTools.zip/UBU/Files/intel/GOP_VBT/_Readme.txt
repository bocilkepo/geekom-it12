#In this folder, the user places the files GOP VBT
#WarAttention! This is aashno!
#Files GOP VBT should be pre-configured.
#UBU does not transfer settings, the user is supposed to do.
#
#The following files are allowed:
#
# Support GOP VBT (omly HSW/BDW v5 and SKL+ v9)
# for version 5
# vbthsw.bin
# for version 9
# Sky/Kaby/Amber/Coffee/Comet Lakes etc
# vbtskl.bin
