
# Only IRSTe or VROC (!!! without VMD) files should be located in this folder.
# RaidOrom.bin DevID 2826
# RaidDriver.efi
# SCUOrom.bin DevID 1D6x
# SCUDriver.efi
# sSataOrom.bin DevID 2827
# sSataDriver.efi



# Only VROC VMD files should be located in this folder.
# Example incl files VROC with VMD + VMDD version 6.0.0.1024

# VROC with WMD 
# VMDVROC_1.efi
# VMDD
# VMDVROC_2.efi